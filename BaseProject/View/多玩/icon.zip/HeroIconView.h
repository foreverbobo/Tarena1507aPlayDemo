//
//  HeroIconView.h
//  BaseProject
//
//  Created by 廖文博 on 15/11/11.
//  Copyright © 2015年 wenbo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroIconView : UIView
@property (nonatomic,strong)NSString *heroName;
@property (nonatomic,assign)NSInteger equipId;
@property (nonatomic,strong)NSString *skillId;
@end
